Socialite Installation Guide: https://bootstrapguru.gitbooks.io/socialite-installation/
Socialite Versions List: https://bootstrapguru.gitbooks.io/socialite-versions/