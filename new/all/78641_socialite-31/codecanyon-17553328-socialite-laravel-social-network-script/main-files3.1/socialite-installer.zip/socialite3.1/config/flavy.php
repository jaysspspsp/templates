<?php

return [

    /*
     * Full path to ffmpeg binary
     */
    'ffmpeg_path' => '/usr/bin/ffmpeg',

    /*
     * Full path to ffprobe binary
     */
    'ffprobe_path' => '/usr/bin/ffprobe',
];
